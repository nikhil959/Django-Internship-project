var send_data = {}

$(document).ready(function () {
}
