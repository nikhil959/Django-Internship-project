from django.urls import path
from django.contrib import admin
admin.autodiscover()

from . import views


urlpatterns = [																																																																																																																																																																																																							
    path('', views.search, name='search'),
   

]
