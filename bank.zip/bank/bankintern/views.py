from django.shortcuts import render
from collections import ChainMap
from rest_framework import serializers
# Create your views here.
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

from django.views.generic import TemplateView
import requests
from django.shortcuts import render
from rest_framework.generics import ListAPIView
from django.views.decorators.cache import cache_page




"""view will be cached for 15 minutes. (Note that I’ve written it as 60 * 15 
for the purpose of readability. 60 * 15 will be evaluated to 900 – that is,
 15 minutes multiplied by 60 seconds per minute.)"""
@cache_page(60 * 15)
def search(request):
    user = {}
    if 'city' in request.GET:
        username = request.GET['city']
        print(username)
        url = 'https://vast-shore-74260.herokuapp.com/banks?city='+ str(username)
        a=[]
        response = requests.get(url)
        request.session['user'] = response.json()
        user = request.session['user']
        print(user)
       

  
    return render(request, 'home.html', {'user': user})
    