from django.apps import AppConfig


class BankinternConfig(AppConfig):
    name = 'bankintern'
